<?php

return [
    // fallback nominal per-invoice kalau data tagihan tidak tersedia
    'default_nominal_per_bulan' => 0,
];
