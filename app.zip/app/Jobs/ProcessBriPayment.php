<?php

namespace App\Jobs;

use Throwable;
use Carbon\Carbon;
use Illuminate\Bus\Queueable;
use Illuminate\Support\Arr;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\Schema;

class ProcessBriPayment implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    // retry & backoff
    public $tries   = 5;
    public $backoff = [10, 30, 60, 120, 300];

    protected string $rawBody;
    protected array $headers;
    protected string $endpoint;

    public function __construct(string $rawBody, array $headers, string $endpoint)
    {
        $this->rawBody  = $rawBody;
        $this->headers  = $headers;
        $this->endpoint = $endpoint;
    }

    public function handle(): void
    {
        $now = Carbon::now();
        $json = json_decode($this->rawBody, true) ?: [];

        // --- Normalisasi payload ---
        $journalSeq = (string) Arr::get($json, 'journalSeq', Arr::get($json, 'journal_seq', ''));
        $custCode   = (string) Arr::get($json, 'custCode', Arr::get($json, 'cust_code', '')); // NIM/custCode: angka, preserve leading zero
        $custCode   = preg_replace('/\D+/', '', $custCode ?? '');
        $bankCode   = (string) Arr::get($json, 'bankCode', Arr::get($json, 'bank_code', ''));
        $brivaNo    = (string) Arr::get($json, 'brivaNo',  Arr::get($json, 'briva_no',  ''));
        $amount     = (int)    Arr::get($json, 'amount',   Arr::get($json, 'nominal',   0));
        $paidAtStr  = (string) Arr::get($json, 'paidAt',   '');

        // --- Audit awal (jika tabel ada) ---
        $logId = null;
        if (Schema::hasTable('webhook_logs')) {
            $logInsert = [
                'endpoint'     => $this->endpoint,
                // pilih kolom yg ada: payload/body, response/meta
                (Schema::hasColumn('webhook_logs', 'headers') ? 'headers' : 'meta') =>
                    json_encode($this->maskHeaders($this->headers), JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),
                (Schema::hasColumn('webhook_logs', 'payload') ? 'payload' : 'body') => $this->rawBody,
                'signature_ok' => 1, // sudah diverifikasi di middleware
                'status_code'  => 202,
                'processed_at' => null,
                'created_at'   => $now,
                'updated_at'   => $now,
            ];
            try {
                $logId = DB::table('webhook_logs')->insertGetId($logInsert);
            } catch (Throwable $e) {
                // non-blocking
            }
        }

        // --- Basic guard ---
        if ($journalSeq === '' || $custCode === '' || $amount <= 0) {
            $this->finalizeLog($logId, 400, ['reason' => 'bad_payload']);
            return;
        }

        // --- Idempotensi global: sudah pernah terpakai? ---
        if ($this->journalSeqExists($journalSeq)) {
            $this->finalizeLog($logId, 200, ['duplicate' => true, 'note' => 'already_processed']);
            return;
        }

        // --- Temukan invoice aktif (prioritas nim; fallback join) ---
        $invoice = $this->findActiveInvoiceByNimSmart($custCode, $bankCode);

        if (!$invoice) {
            $this->recordUnmatched($journalSeq, $custCode, $amount, $json, 'no_active_invoice');
            $this->finalizeLog($logId, 200, ['unmatched' => true, 'reason' => 'no_active_invoice']);
            return;
        }

        // --- Closed amount rule ---
        $expected = (int) ($invoice->jumlah ?? $invoice->nominal ?? $invoice->amount ?? 0);
        if ($expected !== $amount) {
            $this->recordUnmatched($journalSeq, $custCode, $amount, $json, 'amount_mismatch', [
                'expected' => $expected,
            ]);
            $this->finalizeLog($logId, 200, ['unmatched' => true, 'reason' => 'amount_mismatch']);
            return;
        }

        // --- Parse paidAt (fallback now) ---
        try {
            $paidAt = $paidAtStr ? Carbon::parse($paidAtStr) : $now;
        } catch (Throwable $e) {
            $paidAt = $now;
        }

        // --- Apply pelunasan atomik + tahan race unique ---
        try {
            DB::beginTransaction();

            $table = $invoice->getTable();
            $id    = (int) $invoice->id;

            // Status dinamis: invoices(RPL) punya 'Lunas (Otomatis)', invoices_reguler pakai 'Lunas'
            $statusValue = ($table === 'invoices') ? 'Lunas (Otomatis)' : 'Lunas';

            $updates = [
                'status'           => $statusValue,
                'paid_at'          => $paidAt,
                'paid_amount'      => $amount,
                'va_journal_seq'   => $journalSeq,
                'reconcile_source' => Schema::hasColumn($table, 'reconcile_source') ? 'webhook' : null,
                'updated_at'       => Carbon::now(),
            ];

            // Jejak VA kalau kolom ada
            if (Schema::hasColumn($table, 'va_briva_no') && $brivaNo)    $updates['va_briva_no']  = $brivaNo;
            if (Schema::hasColumn($table, 'va_cust_code') && $custCode) $updates['va_cust_code'] = $custCode;
            if (Schema::hasColumn($table, 'va_full') && $bankCode && $custCode) {
                $updates['va_full'] = $bankCode . $custCode;
            }

            // Buang null keys biar gak nulis kolom yg gak ada
            $updates = array_filter($updates, fn($v) => !is_null($v));

            DB::table($table)->where('id', $id)->update($updates);

            DB::commit();
        } catch (QueryException $qe) {
            DB::rollBack();
            // Kena unique va_journal_seq → treat as idempotent
            if (stripos($qe->getMessage(), 'va_journal_seq') !== false) {
                $this->finalizeLog($logId, 200, ['duplicate' => true, 'race' => true]);
                return;
            }
            throw $qe; // biar retry sesuai backoff
        } catch (Throwable $e) {
            DB::rollBack();
            throw $e; // biar retry
        }

        // --- Selesai
        $this->finalizeLog($logId, 200, [
            'ok'         => true,
            'nim'        => $custCode,
            'journalSeq' => $journalSeq,
            'table'      => $invoice->getTable(),
            'row_id'     => $invoice->id ?? null,
        ]);
    }

    public function failed(Throwable $e): void
    {
        Log::error('[BRI] ProcessBriPayment failed: '.$e->getMessage(), [
            'trace' => $e->getTraceAsString()
        ]);
    }

    /* ================= Helpers ================= */

    private function maskHeaders(array $headers): array
    {
        $masked = [];
        foreach ($headers as $k => $v) {
            $kl = strtolower($k);
            if (in_array($kl, ['authorization','x-bri-signature','x-signature'])) {
                $masked[$k] = '***masked***';
            } else {
                $masked[$k] = $v;
            }
        }
        return $masked;
    }

    private function finalizeLog(?int $logId, int $status, array $extra = []): void
    {
        if (!$logId || !Schema::hasTable('webhook_logs')) return;

        $col = Schema::hasColumn('webhook_logs', 'response') ? 'response' : (Schema::hasColumn('webhook_logs', 'meta') ? 'meta' : null);

        $update = [
            'status_code'  => $status,
            'processed_at' => Carbon::now(),
            'updated_at'   => Carbon::now(),
        ];
        if ($col) {
            $update[$col] = json_encode($extra, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        }

        try {
            DB::table('webhook_logs')->where('id', $logId)->update($update);
        } catch (Throwable $e) {
            // non-blocking
        }
    }

    private function recordUnmatched(string $journalSeq, string $nim, int $amount, array $payload, string $reason, array $extra = []): void
    {
        if (!Schema::hasTable('unmatched_payments')) return;

        try {
            DB::table('unmatched_payments')->insert([
                'journal_seq' => $journalSeq,
                'nim'         => $nim ?: null,
                'amount'      => $amount,
                'reason'      => $reason,
                'payload'     => json_encode($payload, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),
                'extra'       => $extra ? json_encode($extra, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) : null,
                'created_at'  => Carbon::now(),
                'updated_at'  => Carbon::now(),
            ]);
        } catch (Throwable $e) {
            // non-blocking
        }
    }

    private function journalSeqExists(string $journalSeq): bool
    {
        foreach ($this->candidateInvoiceTables() as $t) {
            if (!Schema::hasTable($t) || !Schema::hasColumn($t, 'va_journal_seq')) continue;
            if (DB::table($t)->where('va_journal_seq', $journalSeq)->exists()) return true;
        }
        return false;
    }

    /**
     * Cari invoice aktif:
     * - Kalau kolom 'nim' ada di tabel invoice → filter langsung by nim
     * - Kalau tidak: join ke tabel mahasiswa utk filter by nim/cust_code/va_full
     */
    private function findActiveInvoiceByNimSmart(string $nim, string $bankCode): ?object
    {
        $statusCandidates = ['Belum', 'Menunggu Verifikasi', 'Menunggu_verifikasi', 'Pending', 'Belum Lunas'];

        // RPL: invoices
        if (Schema::hasTable('invoices')) {
            $q = DB::table('invoices as inv');
            if (Schema::hasColumn('invoices', 'nim')) {
                $q->where('inv.nim', $nim);
            } else {
                $q->join('mahasiswas as m', 'm.id', '=', 'inv.mahasiswa_id')
                  ->where('m.nim', $nim)
                  ->orWhere(function($qq) use ($nim, $bankCode) {
                      // fallback via VA/cust_code kalau ada
                      $qq->where('m.cust_code', $nim);
                      if ($bankCode) $qq->orWhere('m.va_full', $bankCode.$nim);
                  });
            }
            $row = $q->whereIn('inv.status', $statusCandidates)
                     ->orderBy('inv.angsuran_ke', 'asc')
                     ->select('inv.*', DB::raw("'invoices' as _table"))
                     ->first();
            if ($row) return $this->asModel($row, 'invoices');
        }

        // Reguler: invoices_reguler
        if (Schema::hasTable('invoices_reguler')) {
            $q = DB::table('invoices_reguler as inv');
            if (Schema::hasColumn('invoices_reguler', 'nim')) {
                $q->where('inv.nim', $nim);
            } else {
                $q->join('mahasiswa_reguler as m', 'm.id', '=', 'inv.mahasiswa_reguler_id')
                  ->where('m.nim', $nim)
                  ->orWhere(function($qq) use ($nim, $bankCode) {
                      $qq->where('m.cust_code', $nim);
                      if ($bankCode) $qq->orWhere('m.va_full', $bankCode.$nim);
                  });
            }
            $row = $q->whereIn('inv.status', $statusCandidates)
                     ->orderBy('inv.angsuran_ke', 'asc')
                     ->select('inv.*', DB::raw("'invoices_reguler' as _table"))
                     ->first();
            if ($row) return $this->asModel($row, 'invoices_reguler');
        }

        return null;
    }

    private function asModel(object $row, string $table)
    {
        return new class($table, $row) {
            public string $table;
            public $row;
            public function __construct($table, $row){ $this->table = $table; $this->row = $row; }
            public function __get($k){ return $this->row->$k ?? null; }
            public function __isset($k){ return isset($this->row->$k); }
            public function getTable(){ return $this->table; }
            public function getKeyName(){ return 'id'; }
            public function __toString(){ return json_encode($this->row); }
        };
    }

    private function candidateInvoiceTables(): array
    {
        // urutan penting; sertakan alias aman
        return [
            'invoices',             // RPL
            'invoices_reguler',     // Reguler (nama yang bener)
            'invoice_rpls',         // alias kalau ada
            'invoice_regulers',     // alias kalau ada
        ];
    }
}
